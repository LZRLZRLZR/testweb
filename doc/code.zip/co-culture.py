import cobra
import json
import os
import pandas
import re
import matplotlib.pyplot as plt
import numpy as np
import plotly
import plotly.express as px
import plotly.graph_objs as go
import plotly.io as pio
from cobra.util.solver import linear_reaction_coefficients
from cobra.flux_analysis import flux_variability_analysis
from scipy.integrate import odeint
model_yeast = cobra.io.read_sbml_model('iMH919.xml')

# constrain glucose uptake to 0
model_yeast.objective='biomass_wildType'
glc_exchange = model_yeast.reactions.get_by_id('EX_glc_e_')
glc_exchange.lower_bound = 0


# set sucrose exchange
sucr_exchange = model_yeast.reactions.get_by_id('EX_sucr_e_')
sucr_exchange.lower_bound = -20
sucr_exchange.upper_bound = 0

# release constraints on O2
O2_exchange = model_yeast.reactions.get_by_id('EX_o2_e_')
O2_exchange.lower_bound = -100

def print_active_upt_reactions(model):
    # Print all the uptake reactions with non-zero lower bound
    for reac in model.reactions:
        if re.search(r'exchange', reac.name, re.I) and reac.lower_bound < 0:
            print('{: 8.1f} < v < {: 8.1f}'.format(reac.lower_bound, reac.upper_bound),', ', reac.name, ', id:', reac.id)

solution = model_yeast.optimize()
model_yeast.objective='EX_linalool_e_'
model_yeast.objective.expression
solution = model_yeast.optimize()
model_yeast.objective='EX_alphaionone_e_'
model_yeast.objective.expression

solution = model_yeast.optimize()

model_yeast.objective='EX_betaionone_e_'

model_yeast.objective.expression

solution = model_yeast.optimize()

model_yeast.objective='EX_dihydrobetaionone_e_'
model_yeast.objective.expression
solution = model_yeast.optimize()

model_cyano = cobra.io.read_sbml_model('iRD684.xml')

R_sucrose_cyano = model_cyano.reactions.get_by_id('EX_cscB_c_')
R_sucrose_cyano.lower_bound = 0
R_sucrose_cyano.upper_bound = 1000

model_cyano.objective='Biomass_Auto_2973'
solution = model_cyano.optimize()

model_cyano.objective='EX_cscB_c_'

solution = model_cyano.optimize()

model_cyano.objective='EX_2E_6Z_nonadienal_e_'
solution = model_cyano.optimize()

model_cyano.objective='EX_nonenal_e_'
solution = model_cyano.optimize()



def calculate_derivative(state, t, params):
    # Get models
    model_yeast, model_cyano = params[0], params[1]

    pars = params[2]

    # State of the system, concentrations at time t

    co2g, co2l, X_cyano, nonadienol, nonadienal, sucrose, X_yeast, alpha_ionone, beta_ionone, linalool, dihydro_beta_ionone = \
    state[0], state[1], state[2], state[3], state[4], state[5], state[6], state[7], state[8], state[9], state[10]

    # CO2 tranfer module

    Ico2 = pars["Qgco2"] * pars["co2g_input"]
    print("Ico2: " + str(Ico2))
    Oco2 = pars["Qgco2"] * co2g
    print("Oco2: " + str(Oco2))
    co2sat = pars["beta"] * co2g
    Tco2 = pars["kla"] * (co2sat - co2l)
    print("Tco2: " + str(Tco2))

    # Metabolic modules

    # Cyanobacteria

    model_cyano.objective = 'Biomass_Auto_2973'

    # Uptake of co2 in cyanobacteria

    qco2 = pars["qco2max_cyano"] * (co2l / (pars["Kco2_cyano"] + co2l))
    # print("qco2: " + str(qco2))
    R_CO2_cyano = model_cyano.reactions.get_by_id('EX_CO2')
    R_CO2_cyano.upper_bound = 0
    R_CO2_cyano.lower_bound = -qco2

    # Uptake of photons in cyanobacteria

    qphoton_1 = pars["Ilight_measured"] / 2 * (
                (3600 * pars["reactor_surface"]) / (1000 * state[2] * pars["reactor_volume"]))
    qphoton_2 = pars["Ilight_measured"] / 2 * (
                (3600 * pars["reactor_surface"]) / (1000 * state[2] * pars["reactor_volume"]))
    R_photon1_cyano = model_cyano.reactions.get_by_id('EX_PHO1')
    R_photon1_cyano.lower_bound = -qphoton_1
    R_photon1_cyano.upper_bound = 0
    R_photon2_cyano = model_cyano.reactions.get_by_id('EX_PHO2')
    R_photon2_cyano.lower_bound = -qphoton_2
    R_photon2_cyano.upper_bound = 0

    # Sucrose production in cyanobacteria

    R_sucrose_cyano = model_cyano.reactions.get_by_id('EX_cscB_c_')
    if t < pars["t_IPTG"]:
        R_sucrose_cyano.lower_bound = 0
        R_sucrose_cyano.upper_bound = 0
    else:
        R_sucrose_cyano.upper_bound = 1000  # necessary otherwise bug since lower bound becomes superior thant upper bound
        R_sucrose_cyano.lower_bound = pars["yield_sucrose"] * (qco2)
        R_sucrose_cyano.upper_bound = pars["yield_sucrose"] * (qco2)
    # print("qsucr_cyano: " + str(pars["yield_sucrose"]*(qco2)))

    # Violet leaf aldehydes production in cyanobacteria

    R_nonadienol_cyano = model_cyano.reactions.get_by_id('EX_2E_6Z_nonadienol_e_')
    if t < pars["t_IPTG"] or t < pars["t_theophylline"]:
        R_nonadienol_cyano.lower_bound = 0
        R_nonadienol_cyano.upper_bound = 0

    else:
        R_nonadienol_cyano.upper_bound = 1000  # necessary otherwise bug since lower bound becomes superior thant upper bound
        R_nonadienol_cyano.lower_bound = pars["yield_nonadienol"] * (qco2)
        R_nonadienol_cyano.upper_bound = pars["yield_nonadienol"] * (qco2)
    # print("qnonadienol: " + str(pars["yield_nonadienol"]*(qco2)))

    R_nonadienal_cyano = model_cyano.reactions.get_by_id('EX_2E_6Z_nonadienal_e_')
    if t < pars["t_IPTG"] or t < pars["t_theophylline"]:
        R_nonadienal_cyano.lower_bound = 0
        R_nonadienal_cyano.upper_bound = 0

    else:
        R_nonadienal_cyano.upper_bound = 1000  # necessary otherwise bug since lower bound becomes superior thant upper bound
        R_nonadienal_cyano.lower_bound = pars["yield_nonadienal"] * (qco2)
        R_nonadienal_cyano.upper_bound = pars["yield_nonadienal"] * (qco2)
    # print("qnonadienal: " + str(pars["yield_nonadienal"]*(qco2)))

    #   Optimization of growth with these constraints

    solution_cyano = model_cyano.optimize()

    #   Get fluxes values
    if solution_cyano.status == "infeasible":
        # print("infeasible Cyano solution")
        qco2cyano_upd = 0
        mu_cyano_upd = 0
        qnonadienol_upd = 0
        qnonadienal_upd = 0
        qsucr_cyano_upd = 0

    else:
        qco2cyano_upd = solution_cyano["EX_CO2"]
        mu_cyano_upd = solution_cyano.objective_value
        qnonadienol_upd = solution_cyano["EX_2E_6Z_nonadienol_e_"]
        qnonadienal_upd = solution_cyano["EX_2E_6Z_nonadienal_e_"]
        qsucr_cyano_upd = solution_cyano["EX_cscB_c_"]

    # print("qco2cyano_upd: " + str(qco2cyano_upd))
    # print("mu_cyano_upd: " + str(mu_cyano_upd))
    # print("qnonadienol_upd: " + str(qnonadienol_upd))
    # print("qnonadienal_upd: " + str(qnonadienal_upd))
    # print("qnonadienal_upd: " + str(qnonadienal_upd))

    # Yeast

    if t < pars["t_inoc_yeast"]:  # inoculation of the yeast occurs after the inoculation of the cyanobacteria
        X_yeast = 0
        qsucr_yeast_upd = 0
        mu_yeast_upd = 0
        qalphaionone_upd = 0
        qbetaionone_upd = 0
        qlinalool_upd = 0
        qdihydrobetaionone_upd = 0
        qco2yeast_upd = 0

    else:
        model_yeast.objective = 'biomass_wildType'

        # Uptake of sucrose in yeast

        qsucr_yeast = pars["qsucrmax_yeast"] * (sucrose / (pars["Ksucr_yeast"] + sucrose))
        R_sucrose_yeast = model_yeast.reactions.get_by_id('EX_sucr_e_')
        R_sucrose_yeast.upper_bound = 1000
        R_sucrose_yeast.lower_bound = - qsucr_yeast
        R_sucrose_yeast.upper_bound = - qsucr_yeast
        # print("qsucr_yeast: " + str(qsucr_yeast))

        # Production of the violet terpenes in yeast
        # alpha-ionone production is induced by galactose
        R_alphaionone_yeast = model_yeast.reactions.get_by_id('EX_alphaionone_e_')
        qalphaionone_yeast = pars["yield_alphaionone"] * (qsucr_yeast)
        if t < pars["t_galactose"]:
            R_alphaionone_yeast.lower_bound = 0
            R_alphaionone_yeast.upper_bound = 0
        else:
            R_alphaionone_yeast.upper_bound = 1000  # necessary otherwise bug since lower bound becomes superior thant upper bound
            R_alphaionone_yeast.lower_bound = qalphaionone_yeast
            R_alphaionone_yeast.upper_bound = qalphaionone_yeast
        # print("qalphaionone_yeast: " + str(qalphaionone_yeast))

        # beta-ionone production is induced by tetracycline
        R_betaionone_yeast = model_yeast.reactions.get_by_id('EX_betaionone_e_')
        qbetaionone_yeast = pars["yield_betaionone"] * (qsucr_yeast)
        if t < pars["t_tetracycline"]:
            R_betaionone_yeast.lower_bound = 0
            R_betaionone_yeast.upper_bound = 0
        else:
            R_betaionone_yeast.upper_bound = 1000  # necessary otherwise bug since lower bound becomes superior thant upper bound
            R_betaionone_yeast.lower_bound = qbetaionone_yeast
            R_betaionone_yeast.upper_bound = qbetaionone_yeast
            # print("qbetaionone_yeast: " + str(qbetaionone_yeast))

        # linalool production is induced by copper
        R_linalool_yeast = model_yeast.reactions.get_by_id('EX_linalool_e_')
        qlinalool_yeast = pars["yield_linalool"] * (qsucr_yeast)
        if t < pars["t_copper"]:
            R_linalool_yeast.lower_bound = 0
            R_linalool_yeast.upper_bound = 0
        else:
            R_linalool_yeast.upper_bound = 1000  # necessary otherwise bug since lower bound becomes superior thant upper bound
            R_linalool_yeast.lower_bound = qlinalool_yeast
            R_linalool_yeast.upper_bound = qlinalool_yeast
        # print("qlinalool_yeast: " + str(qlinalool_yeast))

        # dihydro-beta-ionone production is induced by oestradiol
        R_dihydrobetaionone_yeast = model_yeast.reactions.get_by_id('EX_dihydrobetaionone_e_')
        qdihydrobetaionone_yeast = pars["yield_dihydrobetaionone"] * (qsucr_yeast)
        if t < pars["t_oestradiol"]:
            R_dihydrobetaionone_yeast.lower_bound = 0
            R_dihydrobetaionone_yeast.upper_bound = 0
        else:
            R_dihydrobetaionone_yeast.upper_bound = 1000  # necessary otherwise bug since lower bound becomes superior thant upper bound
            R_dihydrobetaionone_yeast.lower_bound = qdihydrobetaionone_yeast
            R_dihydrobetaionone_yeast.upper_bound = qdihydrobetaionone_yeast
            # print("qdihydrobetaionone_yeast: " + str(qdihydrobetaionone_yeast))

        #   Optimization of growth with these constraints
        solution_yeast = model_yeast.optimize()

        #   Get fluxes values
        if solution_yeast.status == "infeasible":
            # print("infeasible Yeast solution")
            qsucr_yeast_upd = 0
            mu_yeast_upd = 0
            qalphaionone_upd = 0
            qbetaionone_upd = 0
            qlinalool_upd = 0
            qdihydrobetaionone_upd = 0
            qco2yeast_upd = 0

        else:
            qalphaionone_upd = solution_yeast["EX_alphaionone_e_"]
            qbetaionone_upd = solution_yeast["EX_betaionone_e_"]
            qlinalool_upd = solution_yeast["EX_linalool_e_"]
            qdihydrobetaionone_upd = solution_yeast["EX_dihydrobetaionone_e_"]
            mu_yeast_upd = solution_yeast['biomass_wildType']
            qco2yeast_upd = solution_yeast["EX_co2_e_"]
            qsucr_yeast_upd = solution_yeast["EX_sucr_e_"]

        # print("qsucr_yeast_upd: " + str(qsucr_yeast_upd))
        # print("mu_yeast_upd: " + str(mu_yeast_upd))
        # print("qalphaionone_upd: " + str(qalphaionone_upd))
        # print("qbetaionone_upd: " + str(qbetaionone_upd))
        # print("qlinalool_upd: " + str(qlinalool_upd))
        # print("qdihydrobetaionone_upd: " + str(qdihydrobetaionone_upd))
        # print("qco2yeast_upd: " + str(qco2yeast_upd))

    # Calculate derivatives: Accumulation = Input - Output + Production

    dco2gdt = Ico2 - Tco2 - Oco2
    dco2ldt = Tco2 + qco2yeast_upd * X_yeast + qco2cyano_upd * X_cyano  # qco2cyano_upd is negative
    dX_cyanodt = X_cyano * mu_cyano_upd
    dnonadienoldt = qnonadienol_upd * X_cyano
    dnonadienaldt = qnonadienal_upd * X_cyano
    dsucrosedt = qsucr_cyano_upd * X_cyano + qsucr_yeast_upd * X_yeast  # qsucr_yeast_upd is negative
    dX_yeastdt = X_yeast * mu_yeast_upd
    dalphaiononedt = qalphaionone_upd * X_yeast
    dbetaiononedt = qbetaionone_upd * X_yeast
    dlinalooldt = qlinalool_upd * X_yeast
    ddihydrobetaiononedt = qdihydrobetaionone_upd * X_yeast

    return [dco2gdt, dco2ldt, dX_cyanodt, dnonadienoldt, dnonadienaldt, dsucrosedt, dX_yeastdt, dalphaiononedt,Ico2,Oco2,Tco2]
# Set initial conditions
initial_values = [10, #co2g
                  10, #co2l
                  0.1, #X_cyano
                  0, #nonadienol
                  0, #nonadienal
                  0, #sucrose
                  0.1, #X_yeast
                  0, #alphaionone
                  0, #betaionone
                  0, #linalool
                  0] #dihydrobetaionone
pars = {  # Transfer parameters
    "beta": 0.028511,
    "kla": 12.5,
    "Qgco2": 204,
    "co2g_input": 41,
    "Ilight_measured": 3000,

    # Biochemical parameters
    "Ksucr_yeast": 1,
    "Kco2_cyano": 1,
    "qco2max_cyano": 18.8,
    "qsucrmax_yeast": 3.0,

    "yield_alphaionone": 0.002,
    "yield_betaionone": 0.002,
    "yield_linalool": 0.008,
    "yield_dihydrobetaionone": 0.002,

    "yield_sucrose": 0.067,
    "yield_nonadienol": 0.00032,
    "yield_nonadienal": 0.00032,

    # Induction times
    "t_galactose": 15,
    "t_tetracycline": 15,
    "t_oestradiol": 15,
    "t_copper": 15,
    "t_IPTG": 3,
    "t_theophylline": 15,

    # Yeast inoculation
    "t_inoc_yeast": 5,

    # Reactor dimensions
    "reactor_volume": 180,
    "reactor_surface": 3.6
}
# Run a simulation of the dynamics of the consortium

# define simulation times
sim_times = np.linspace(0,168,1681)

# solve ODEs
extra_params = (model_yeast, model_cyano, pars)
sim_results = odeint(calculate_derivative, initial_values, sim_times, args=(extra_params,), rtol=1.e-6, atol =1.e-6) # sim_results is a matrix containing for each t the concentration of each specie of interest as lines

plt.figure()
plt.plot(sim_times, np.dot(0.5,sim_results[:,8]),'b--',linestyle='dotted', label ='Ico2')

plt.legend()
plt.xlabel('time (h)')
plt.ylabel('[Ico2,Oco2,Tco2] (mM)')
plt.show()