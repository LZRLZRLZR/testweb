# iGEM-Group 4-TeamMeeting-11

时间：2024/2/23

## 项目跟进

Project（DDL：23 +0.5）

​	Description：lwj 【主体已经完成】

​	Design：lwj(co: gjt zcx) 【目前已经收到佳忆的最终版的design】

​	Troubleshooting：lwj（DDL：25）【今晚写】

Wet Lab（DDL：24+0.5）

​	Engineering：zcx(same) [光控元件的选择；融合蛋白的设计]【】

​	Protocol：yjy (zcx gjt)  【目前有佳忆部分的内容，】

​	Notebook：（不写？）

Dry Lab（DDL:23+0.5）

​	Model：lwj( yjy )【通量平衡分析与碳衡算已完成，Alphafold2辅助设计融合蛋白已经做完，差码字】

​	Results：  【同上】

Human Practices(Edu, interal) :lwj( zcx )（DDL：24）【integrated human practice 已经完成】

Safety: lwj(DDL:25)【明天写】

## wiki

刘子瑞

- 收照片（4:5）：头像在中上，近期真人

- 收task（Project reviews / journal club / Brainstorm / Wet Lab / Dry Lab / Wiki ）

- 标题不能太长（bits）
- 南区一起肝





