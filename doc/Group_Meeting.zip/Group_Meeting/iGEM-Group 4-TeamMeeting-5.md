# iGEM-Group 4-TeamMeeting-5

时间：2024/2/8

## Journal Club

1. 化11-李玮杰 微生物群体效应

2. 药2-张程雪 rna干扰技术

3. 药3-杨佳忆 纳米酶

4. 环3-龚建廷  生物传感器

5. 探微-环2 刘子瑞 蛋白质聚类分析2（算法简介与数据库使用）

## 优秀项目分享

6. 鹿为民
   2023-AFCM-Egypt

## 关于下一次例会（brain storm)

- 方向：生物合成（biomanufacturing）

- 利用好共享文档

- 利用好这几次的分享

  