# iGEM-Group 4-TeamMeeting-1

时间：2024/1/28

## 寒训要求

**一、iGEM quick start**

 iGEM官网（https://igem.org）提供了丰富的资源以帮助New iGEMer快速入门，阅读官网上的各个标签页（重点关注Competition, Technology, Responsibility子标签页）以熟悉：1.iGEM的比赛形式；2.iGEM的奖项设置与评定细则；3.iGEM可提供的技术、国内外团队交互等方面的资源**。仔细阅读官网中Competition子标签页上Judging栏，**以文稿的形式整理归纳Medal、Awards的详细设置与评判细则。

 

**二、iGEM Simulation.**

冬训营成员以小组的形式进行iGEM备赛过程模拟，最终团队应呈递：1.Winter Project Presentation（Background+Design+Modeling+Safety&Feasibility+Human Practices）；2.Wiki（Team+Project+Human Practices）。参赛队的最终人选将从各个小组中择优确定。

Tips：

①建议小组成员自行商定Group meeting时间。在寒训前期的Group meeting中以Brainstorm为主，建议的形式为团队成员分享事先准备的前沿文献、历年优秀项目，谈自己的体会与启发，在交流讨论中产生New idea；在寒训中期的Group meeting中对前期讨论积累的New idea进行深入剖析，从创新性、可行性等方面进行综合筛选，确立最终的Project；在寒训后期进行分工准备最终呈现作品。

②意向湿实验的同学主要负责项目的Design部分；意向建模的同学多关注优秀队伍的Wiki中的Modeling部分，在充分了解Design后选择1-2个关键过程进行建模；意向人类文明实践的同学根据团队最终确定的Project，给出一个详细的人类文明实践行动计划；意向Wiki的同学多关注优秀队伍的Wiki设计，将团队最终成果呈现在网页上；意向美工的同学负责PPT与Wiki的美化。

## 确定例会频率&时间

三天一次，下一次：周三，周六。19:00-22:00



## 人员分工

建模：利用计算机手段模拟部分设计，预测效果。（通路模拟，分子模拟）

美工：ppt设计，wiki美化

网页：wiki

人类文明实践：sale the project

湿实验：实验方案设计



|        | 建模 | 美工 | 网页 | 人类文明实践 | 湿实验 |
| ------ | ---- | ---- | ---- | ------------ | ------ |
| 李玮杰 |      |      |      | ✅            | ✅      |
| 刘子瑞 | ✅    |      | ✅    |              |        |
| 杨佳忆 | ✅    |      |      |              | ✅      |
| 龚建廷 | ✅    |      |      |              | ✅      |
| 张恩溥 |      | ✅    | ✅    |              |        |
| 张程雪 |      |      |      | ✅            | ✅      |
| 鹿为民 |      |      |      |              | ✅      |

## 下一次例会前任务

1. 

一、iGEM quick start

 iGEM官网（https://igem.org）提供了丰富的资源以帮助New iGEMer快速入门，阅读官网上的各个标签页（重点关注Competition, Technology, Responsibility子标签页）以熟悉：1.iGEM的比赛形式；2.iGEM的奖项设置与评定细则；3.iGEM可提供的技术、国内外团队交互等方面的资源**。仔细阅读官网中Competition子标签页上Judging栏，**以文稿的形式整理归纳Medal、Awards的详细设置与评判细则。

## 讲项目



23: 最佳建模奖

22： 

21：

仔细阅读官网中Competition子标签页上Judging栏，**以文稿的形式整理归纳Medal、Awards的详细设置与评判细则。

(刘子瑞)